package Assignment;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

public class MainPage extends JFrame {

    public MainPage() {
        setTitle("APU Psychology Consultation Management System");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 500);
        setResizable(false);
        getContentPane().setBackground(new Color(245, 245, 245));
        setLayout(new GridBagLayout());
        ((JPanel) getContentPane()).setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        GridBagConstraints layout = new GridBagConstraints();
        layout.insets = new Insets(10, 10, 10, 10);
        layout.fill = GridBagConstraints.HORIZONTAL;
        layout.weightx = 1.0;

        // Title Label
        JLabel label1 = new JLabel("Welcome to APU Psychology Consultation Management System", SwingConstants.CENTER);
        label1.setFont(new Font("Arial", Font.BOLD, 22));
        label1.setForeground(new Color(60, 60, 120));
        layout.gridx = 0;
        layout.gridy = 0;
        layout.gridwidth = 2;
        add(label1, layout);

        // Username label and text field
        JLabel usernameLabel = new JLabel("Username:");
        usernameLabel.setFont(new Font("Arial", Font.PLAIN, 18));
        layout.gridx = 0;
        layout.gridy = 1;
        layout.gridwidth = 1;
        add(usernameLabel, layout);

        JTextField usernameField = new JTextField(20);
        usernameField.setFont(new Font("Arial", Font.PLAIN, 16));
        layout.gridx = 1;
        add(usernameField, layout);

        // Password label and text field
        JLabel passwordLabel = new JLabel("Password:");
        passwordLabel.setFont(new Font("Arial", Font.PLAIN, 18));
        layout.gridx = 0;
        layout.gridy = 2;
        add(passwordLabel, layout);

        JPasswordField passwordField = new JPasswordField(20);
        passwordField.setFont(new Font("Arial", Font.PLAIN, 16));
        layout.gridx = 1;
        add(passwordField, layout);

        // Role label and combo box (for both registration and login)
        JLabel roleLabel = new JLabel("Role:");
        roleLabel.setFont(new Font("Arial", Font.PLAIN, 18));
        layout.gridx = 0;
        layout.gridy = 3;
        add(roleLabel, layout);

        String[] roles = {"Lecturer", "Student"};
        JComboBox<String> roleboxA = new JComboBox<>(roles);
        roleboxA.setFont(new Font("Arial", Font.PLAIN, 16));
        roleboxA.setBackground(Color.WHITE);
        layout.gridx = 1;
        add(roleboxA, layout);

        // Login and Register buttons
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        buttonPanel.setBackground(new Color(245, 245, 245));

        JButton registerButton = createStyledButton("Register");
        JButton loginButton = createStyledButton("Log in");

        buttonPanel.add(registerButton);
        buttonPanel.add(loginButton);
        layout.gridx = 0;
        layout.gridy = 4;
        layout.gridwidth = 2;
        add(buttonPanel, layout);

        setVisible(true);
        
        File userFile = new File("users.txt");
        if (!userFile.exists()) {
            try {
                userFile.createNewFile();
            } catch (IOException e) {
                JOptionPane.showMessageDialog(this, "Error creating user data file.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }

        // Register button action
        registerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String username = usernameField.getText();
                String password = new String(passwordField.getPassword());
                String role = (String) roleboxA.getSelectedItem();

                if (username.isEmpty() || password.isEmpty()) {
                    JOptionPane.showMessageDialog(MainPage.this, "Username and Password cannot be empty.", "Error", JOptionPane.ERROR_MESSAGE);
                } else {
                    try {
                        // Check if the username already exists in the users.txt file
                        if (isUsernameTaken(username)) {
                            JOptionPane.showMessageDialog(MainPage.this, "Username is already taken. Please choose a different one.", "Error", JOptionPane.ERROR_MESSAGE);
                        } else {
                            // Generate a unique User ID
                            String userID = generateUniqueID();

                            try (BufferedWriter writer = new BufferedWriter(new FileWriter("users.txt", true))) {
                                writer.write(userID + "," + username + "," + password + "," + role);
                                writer.newLine();
                                JOptionPane.showMessageDialog(MainPage.this, 
                                    "Registration successful! Your User ID is: " + userID, 
                                    "Success", JOptionPane.INFORMATION_MESSAGE);
                            }
                        }
                    } catch (IOException ex) {
                        JOptionPane.showMessageDialog(MainPage.this, "Error saving user data.", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                }
            }

            // Method to check if the username already exists in the users.txt file
            private boolean isUsernameTaken(String username) throws IOException {
                try (BufferedReader reader = new BufferedReader(new FileReader("users.txt"))) {
                    String line;
                    while ((line = reader.readLine()) != null) {
                        String[] parts = line.split(",");
                        if (parts[1].equals(username)) {
                            return true; // Username found, it's already taken
                        }
                    }
                }
                return false; // Username not found, it's available
            }

            // Method to generate a unique User ID
            private String generateUniqueID() {
                String uniqueID;
                boolean isUnique;
                do {
                    uniqueID = "U" + (int) (Math.random() * 10000); // Generate random ID
                    isUnique = true;

                    // Check if the ID already exists in the file
                    try (BufferedReader reader = new BufferedReader(new FileReader("users.txt"))) {
                        String line;
                        while ((line = reader.readLine()) != null) {
                            String[] parts = line.split(",");
                            if (parts[0].equals(uniqueID)) {
                                isUnique = false; // Found a duplicate, regenerate ID
                                break;
                            }
                        }
                    } catch (IOException ex) {
                        // File might not exist yet, so no duplicates
                        isUnique = true;
                    }
                } while (!isUnique);

                return uniqueID;
            }
        });

        // Login button action
        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String username = usernameField.getText();
                String password = new String(passwordField.getPassword());
                String selectedRole = (String) roleboxA.getSelectedItem();
                if (username.isEmpty() || password.isEmpty()) {
                    JOptionPane.showMessageDialog(MainPage.this, "Username, Password, and Role cannot be empty.", "Error", JOptionPane.ERROR_MESSAGE);
                } else {
                    try (BufferedReader reader = new BufferedReader(new FileReader("users.txt"))) {
                        String line;
                        boolean found = false;
                        while ((line = reader.readLine()) != null) {
                            String[] parts = line.split(",");
                            if (parts[1].equals(username) && parts[2].equals(password) && parts[3].equals(selectedRole)) {
                                found = true;
                                JOptionPane.showMessageDialog(MainPage.this, 
                                    "Login successful! Welcome, " + parts[3], 
                                    "Success", JOptionPane.INFORMATION_MESSAGE);
                                MainPage.this.dispose();
                                // Pass username to StudentPage or LecturerPage based on role
                                if (parts[3].equals("Student")) {
                                    new StudentPage(username);
                                } else if (parts[3].equals("Lecturer")) {
                                    new LecturerPage(username);
                                }
                                break;
                            }
                        }
                        if (!found) {
                            JOptionPane.showMessageDialog(MainPage.this, "Invalid Username, Password, or Role.", "Error", JOptionPane.ERROR_MESSAGE);
                        }
                    } catch (IOException ex) {
                        JOptionPane.showMessageDialog(MainPage.this, "Error reading user data.", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                }
            }
        });
    }

    private JButton createStyledButton(String text) {
        JButton button = new JButton(text);
        button.setFocusPainted(false);
        button.setBackground(new Color(60, 60, 120));
        button.setForeground(Color.WHITE);
        button.setFont(new Font("Arial", Font.BOLD, 16));
        button.setPreferredSize(new Dimension(120, 40));
        button.setBorder(BorderFactory.createLineBorder(new Color(60, 60, 120)));
        return button;
    }

    public static void main(String[] args) {
        new MainPage();
    }
}
