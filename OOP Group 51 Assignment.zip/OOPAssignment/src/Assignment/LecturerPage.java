package Assignment;

import java.awt.*;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;

public class LecturerPage extends JFrame {
    // Store the lecturer's name
    private String lecturerName;  

    private DefaultTableModel availableSlotsModel;
    private JTable availableSlotsTable;
    private DefaultTableModel bookedAppointmentsModel;
    private JTable bookedAppointmentsTable;
    private DefaultTableModel rescheduleRequestsModel;
    private JTable rescheduleRequestsTable;
    private DefaultTableModel feedbackModel;
    private JTable feedbackTable;

    public LecturerPage(String lecturerName) {
        this.lecturerName = lecturerName;

        setTitle("Lecturer Management");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(1500, 800);
        setResizable(true);
        getContentPane().setBackground(new Color(235, 242, 250));
        setLayout(new BorderLayout(10, 10));
        ((JPanel) getContentPane()).setBorder(new EmptyBorder(10, 10, 10, 10));

        // Set up header panel
        JPanel headerPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        headerPanel.setBackground(new Color(59, 89, 152));
        headerPanel.setBorder(new EmptyBorder(10, 10, 10, 10));

        JLabel titleLabel = new JLabel("Lecturer Slot Management");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        titleLabel.setForeground(Color.WHITE);
        headerPanel.add(titleLabel);

        add(headerPanel, BorderLayout.NORTH);

        // Set up center panel for main components
        JPanel centerPanel = new JPanel(new GridLayout(2, 2, 10, 10));
        centerPanel.setOpaque(false);

        // Available Slots Table
        availableSlotsModel = new DefaultTableModel(new String[]{"Lecturer Name", "Date (MM/DD/YYYY)", "Time", "Duration (mins)", "Select"}, 0) {
            @Override
            public Class<?> getColumnClass(int columnIndex) {
                return columnIndex == 4 ? Boolean.class : String.class;
            }

            @Override
            public boolean isCellEditable(int row, int column) {
                // Only the "Select" column is editable (checkbox)
                return column == 4;
            }
        };
        availableSlotsTable = new JTable(availableSlotsModel);
        availableSlotsTable.setRowHeight(25);
        enableSortingByDateTime(availableSlotsTable, availableSlotsModel, 1, 2);
        JScrollPane availableSlotsScrollPane = new JScrollPane(availableSlotsTable);
        availableSlotsScrollPane.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(new Color(59, 89, 152)), "Available Slots", 0, 0, new Font("Arial", Font.BOLD, 14), new Color(59, 89, 152)));
        centerPanel.add(availableSlotsScrollPane);

        // Booked Appointments Table
        bookedAppointmentsModel = new DefaultTableModel(new String[]{"Student", "Lecturer", "Date (MM/DD/YYYY)", "Time", "Duration (mins)", "Status", "Select"}, 0) {
            @Override
            public Class<?> getColumnClass(int columnIndex) {
                return columnIndex == 6 ? Boolean.class : String.class;
            }

            @Override
            public boolean isCellEditable(int row, int column) {
                // Only the "Select" column is editable (checkbox)
                return column == 6;
            }
        };
        bookedAppointmentsTable = new JTable(bookedAppointmentsModel);
        bookedAppointmentsTable.setRowHeight(25);
        enableSortingByDateTime(bookedAppointmentsTable, bookedAppointmentsModel, 2, 3);
        JScrollPane bookedAppointmentsScrollPane = new JScrollPane(bookedAppointmentsTable);
        bookedAppointmentsScrollPane.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(new Color(59, 89, 152)), "Booked Appointments", 0, 0, new Font("Arial", Font.BOLD, 14), new Color(59, 89, 152)));
        centerPanel.add(bookedAppointmentsScrollPane);

        // Reschedule Requests Table
        rescheduleRequestsModel = new DefaultTableModel(new String[]{"Student", "Lecturer", "Current Date", "Requested Date", "Requested Time", "Select"}, 0) {
            @Override
            public Class<?> getColumnClass(int columnIndex) {
                return columnIndex == 5 ? Boolean.class : String.class;
            }

            @Override
            public boolean isCellEditable(int row, int column) {
                // Only the "Select" column is editable (checkbox)
                return column == 5;
            }
        };
        rescheduleRequestsTable = new JTable(rescheduleRequestsModel);
        rescheduleRequestsTable.setRowHeight(25);
        enableSortingByDateTime(rescheduleRequestsTable, rescheduleRequestsModel, 3, 4);
        JScrollPane rescheduleRequestsScrollPane = new JScrollPane(rescheduleRequestsTable);
        rescheduleRequestsScrollPane.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(new Color(59, 89, 152)), "Reschedule Requests", 0, 0, new Font("Arial", Font.BOLD, 14), new Color(59, 89, 152)));
        centerPanel.add(rescheduleRequestsScrollPane);

        // Feedback Table
        feedbackModel = new DefaultTableModel(new String[]{"Student Name", "Lecturer Name", "Date (MM/DD/YYYY)", "Time", "Status", "Student Feedback", "Lecturer Feedback"}, 0);
        feedbackTable = new JTable(feedbackModel);
        feedbackTable.setRowHeight(25);
        enableSortingByDateTime(feedbackTable, feedbackModel, 2, 3);
        JScrollPane feedbackScrollPane = new JScrollPane(feedbackTable);
        feedbackScrollPane.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(new Color(59, 89, 152)), "Student Feedback", 0, 0, new Font("Arial", Font.BOLD, 14), new Color(59, 89, 152)));
        centerPanel.add(feedbackScrollPane);
        add(centerPanel, BorderLayout.CENTER);

        // Bottom Panel for Buttons
        JPanel bottomPanel = new JPanel(new GridLayout(2, 4, 10, 10)); // Changed from FlowLayout to GridLayout with 2 rows and 4 columns
        bottomPanel.setBackground(new Color(235, 242, 250));
        bottomPanel.setBorder(new EmptyBorder(10, 0, 10, 0));

        JButton addSlotButton = createStyledButton("Add Slot");
        JButton editSlotButton = createStyledButton("Edit Selected Slot");
        JButton removeSlotButton = createStyledButton("Remove Selected Slots");
        JButton provideFeedbackButton = createStyledButton("Provide Feedback");
        JButton approveRescheduleButton = createStyledButton("Approve Reschedule");
        JButton rejectRescheduleButton = createStyledButton("Reject Reschedule");
        JButton cancelAppointmentButton = createStyledButton("Cancel Appointment"); // New Button
        JButton logoutButton = createStyledButton("Log Out");

        bottomPanel.add(addSlotButton);
        bottomPanel.add(editSlotButton);
        bottomPanel.add(removeSlotButton);
        bottomPanel.add(provideFeedbackButton);
        bottomPanel.add(approveRescheduleButton);
        bottomPanel.add(rejectRescheduleButton);
        bottomPanel.add(cancelAppointmentButton); // Add new button to panel
        bottomPanel.add(logoutButton);

        add(bottomPanel, BorderLayout.SOUTH);

        // Load data from files
        loadAvailableSlotsFromFile("available_slots.txt");
        loadAppointmentsFromFile("appointments.txt");
        loadRescheduleRequestsFromFile("reschedule_requests.txt");
        loadFeedbackFromFile("feedback.txt");

        // Add slot button action listener
        addSlotButton.addActionListener(e -> {
            JPanel addSlotPanel = new JPanel(new GridLayout(4, 2, 10, 10));

            JLabel dateLabel = new JLabel("Date (MM/DD/YYYY):");
            JTextField dateField = new JTextField(10);
            addSlotPanel.add(dateLabel);
            addSlotPanel.add(dateField);

            JLabel timeLabel = new JLabel("Time:");
            JComboBox<String> timeBox = new JComboBox<>(new String[]{"08:30 AM", "09:00 AM", "09:30 AM", "10:00 AM", "10:30 AM", "11:00 AM", "11:30 AM", "12:00 PM", "12:30 PM",
                    "01:00 PM", "01:30 PM", "02:00 PM", "02:30 PM", "03:00 PM", "03:30 PM", "04:00 PM", "04:30 PM", "05:00 PM", "05:30 PM", "06:00 PM", "06:30 PM"});
            addSlotPanel.add(timeLabel);
            addSlotPanel.add(timeBox);

            JLabel durationLabel = new JLabel("Duration (mins):");
            JComboBox<String> durationBox = new JComboBox<>(new String[]{"30", "60", "90","120","150","180"});
            addSlotPanel.add(durationLabel);
            addSlotPanel.add(durationBox);

            int result = JOptionPane.showConfirmDialog(null, addSlotPanel, "Add Slot", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
            if (result == JOptionPane.OK_OPTION) {
                String date = dateField.getText();
                String time = (String) timeBox.getSelectedItem();
                String duration = (String) durationBox.getSelectedItem();
                if (!date.isEmpty() && time != null && duration != null) {
                    availableSlotsModel.addRow(new Object[]{lecturerName, date, time, duration, false});
                    saveSlotsToFile("available_slots.txt", lecturerName, date, time, duration);
                } else {
                    JOptionPane.showMessageDialog(LecturerPage.this, "Please enter a valid date, time, and duration.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        // Edit Slot Button Action Listener
        editSlotButton.addActionListener(e -> {
            int selectedRow = availableSlotsTable.getSelectedRow();
            if (selectedRow != -1) {
                String currentDate = (String) availableSlotsModel.getValueAt(selectedRow, 1);
                String currentTime = (String) availableSlotsModel.getValueAt(selectedRow, 2);
                String currentDuration = (String) availableSlotsModel.getValueAt(selectedRow, 3);

                JPanel editSlotPanel = new JPanel(new GridLayout(3, 2, 10, 10));

                JLabel dateLabel = new JLabel("New Date (MM/DD/YYYY):");
                JTextField dateField = new JTextField(currentDate, 10);
                editSlotPanel.add(dateLabel);
                editSlotPanel.add(dateField);

                JLabel timeLabel = new JLabel("New Time:");
                JComboBox<String> timeBox = new JComboBox<>(new String[]{"08:30 AM", "09:00 AM", "09:30 AM", "10:00 AM", "10:30 AM", "11:00 AM", "11:30 AM", "12:00 PM", "12:30 PM",
                        "01:00 PM", "01:30 PM", "02:00 PM", "02:30 PM", "03:00 PM", "03:30 PM", "04:00 PM", "04:30 PM", "05:00 PM", "05:30 PM", "06:00 PM", "06:30 PM"});
                timeBox.setSelectedItem(currentTime);
                editSlotPanel.add(timeLabel);
                editSlotPanel.add(timeBox);

                JLabel durationLabel = new JLabel("New Duration (mins):");
                JComboBox<String> durationBox = new JComboBox<>(new String[]{"30", "60", "90","120","150","180"});
                durationBox.setSelectedItem(currentDuration);
                editSlotPanel.add(durationLabel);
                editSlotPanel.add(durationBox);

                int result = JOptionPane.showConfirmDialog(null, editSlotPanel, "Edit Slot", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
                if (result == JOptionPane.OK_OPTION) {
                    String newDate = dateField.getText();
                    String newTime = (String) timeBox.getSelectedItem();
                    String newDuration = (String) durationBox.getSelectedItem();
                    if (!newDate.isEmpty() && newTime != null && newDuration != null) {
                        availableSlotsModel.setValueAt(newDate, selectedRow, 1);
                        availableSlotsModel.setValueAt(newTime, selectedRow, 2);
                        availableSlotsModel.setValueAt(newDuration, selectedRow, 3);
                        saveAllSlotsToFile("available_slots.txt");
                    } else {
                        JOptionPane.showMessageDialog(LecturerPage.this, "Please enter a valid date, time, and duration.", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                }
            } else {
                JOptionPane.showMessageDialog(LecturerPage.this, "Please select a slot to edit.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        // Remove Slot Button Action Listener
        removeSlotButton.addActionListener(e -> {
            boolean anySelected = false;
            for (int i = availableSlotsModel.getRowCount() - 1; i >= 0; i--) {
                Boolean isSelected = (Boolean) availableSlotsModel.getValueAt(i, 4);
                if (isSelected != null && isSelected) {
                    availableSlotsModel.removeRow(i);
                    anySelected = true;
                }
            }
            if (anySelected) {
                saveAllSlotsToFile("available_slots.txt");
                JOptionPane.showMessageDialog(LecturerPage.this, "Selected slots removed successfully.", "Slots Removed", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(LecturerPage.this, "No slots selected to remove.", "No Selection", JOptionPane.WARNING_MESSAGE);
            }
        });

        // Provide Feedback Button Action Listener
        provideFeedbackButton.addActionListener(e -> {
            int selectedRow = feedbackTable.getSelectedRow();
            if (selectedRow != -1) {
                String lecturerFeedback = JOptionPane.showInputDialog("Enter your feedback for the student:");
                if (lecturerFeedback != null && !lecturerFeedback.trim().isEmpty()) {
                    feedbackModel.setValueAt(lecturerFeedback, selectedRow, 6);
                    saveAllFeedbackToFile("feedback.txt"); 
                    JOptionPane.showMessageDialog(LecturerPage.this, "Feedback submitted successfully.", "Feedback Submitted", JOptionPane.INFORMATION_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(LecturerPage.this, "Please select a feedback entry to provide feedback.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        // Approve Reschedule Button Action Listener
        approveRescheduleButton.addActionListener(e -> {
            boolean anySelected = false;
            for (int i = rescheduleRequestsModel.getRowCount() - 1; i >= 0; i--) {
                Boolean isSelected = (Boolean) rescheduleRequestsModel.getValueAt(i, 5);
                if (isSelected != null && isSelected) {
                    String student = (String) rescheduleRequestsModel.getValueAt(i, 0);
                    String lecturer = (String) rescheduleRequestsModel.getValueAt(i, 1);
                    String requestedDate = (String) rescheduleRequestsModel.getValueAt(i, 3);
                    String requestedTime = (String) rescheduleRequestsModel.getValueAt(i, 4);

                    // Add approved request to booked appointments table
                    bookedAppointmentsModel.addRow(new Object[]{student, lecturer, requestedDate, requestedTime, "60", "Approved", false});

                    // Remove the approved reschedule request
                    rescheduleRequestsModel.removeRow(i);
                    anySelected = true;
                }
            }
            if (anySelected) {
                saveAllAppointmentsToFile("appointments.txt");
                saveAllRescheduleRequestsToFile("reschedule_requests.txt");
                JOptionPane.showMessageDialog(LecturerPage.this, "Selected reschedule requests approved.", "Reschedule Approved", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(LecturerPage.this, "No reschedule requests selected to approve.", "No Selection", JOptionPane.WARNING_MESSAGE);
            }
        });

        // Reject Reschedule Button Action Listener
        rejectRescheduleButton.addActionListener(e -> {
            boolean anySelected = false;
            for (int i = rescheduleRequestsModel.getRowCount() - 1; i >= 0; i--) {
                Boolean isSelected = (Boolean) rescheduleRequestsModel.getValueAt(i, 5);
                if (isSelected != null && isSelected) {
                    rescheduleRequestsModel.removeRow(i);
                    anySelected = true;
                }
            }
            if (anySelected) {
                saveAllRescheduleRequestsToFile("reschedule_requests.txt");
                JOptionPane.showMessageDialog(LecturerPage.this, "Selected reschedule requests rejected.", "Reschedule Rejected", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(LecturerPage.this, "No reschedule requests selected to reject.", "No Selection", JOptionPane.WARNING_MESSAGE);
            }
        });

        // Cancel Appointment Button Action Listener (New Functionality)
        cancelAppointmentButton.addActionListener(e -> {
            boolean anySelected = false;
            for (int i = bookedAppointmentsModel.getRowCount() - 1; i >= 0; i--) {
                Boolean isSelected = (Boolean) bookedAppointmentsModel.getValueAt(i, 6);
                if (isSelected != null && isSelected) {
                    String student = (String) bookedAppointmentsModel.getValueAt(i, 0);
                    String lecturer = (String) bookedAppointmentsModel.getValueAt(i, 1);
                    String date = (String) bookedAppointmentsModel.getValueAt(i, 2);
                    String time = (String) bookedAppointmentsModel.getValueAt(i, 3);
                    String duration = (String) bookedAppointmentsModel.getValueAt(i, 4);
                    String status = (String) bookedAppointmentsModel.getValueAt(i, 5);

                    // Confirm cancellation
                    int confirm = JOptionPane.showConfirmDialog(this,
                            "Are you sure you want to cancel the appointment with " + student + " on " + date + " at " + time + "?",
                            "Confirm Cancellation", JOptionPane.YES_NO_OPTION);

                    if (confirm == JOptionPane.YES_OPTION) {
                        // Remove the appointment from the booked appointments table
                        bookedAppointmentsModel.removeRow(i);

                        // Add the canceled appointment to the feedback table with status "Canceled"
                        feedbackModel.addRow(new Object[]{student, lecturer, date, time, "Canceled", "", ""});
                        anySelected = true;
                    }
                }
            }
            if (anySelected) {
                saveAllAppointmentsToFile("appointments.txt");
                saveAllFeedbackToFile("feedback.txt");
                JOptionPane.showMessageDialog(LecturerPage.this, "Selected appointments canceled successfully.", "Appointments Canceled", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(LecturerPage.this, "No appointments selected to cancel.", "No Selection", JOptionPane.WARNING_MESSAGE);
            }
        });

        // Log Out Button Action Listener
        logoutButton.addActionListener(e -> {
            dispose();
            new MainPage(); // Go back to the login page
        });

        // Timer to move Past appointments to feedback table
        Timer timer = new Timer(true);
        timer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                SwingUtilities.invokeLater(() -> {
                    movePastAppointmentsToFeedback();
                    removePastAvailableSlots();
                });
            }
        }, 0, 60 * 1000);  // Check every minute

        setVisible(true);
    }
    
    private JButton createStyledButton(String text) {
        JButton button = new JButton(text);
        button.setFocusPainted(false);
        button.setBackground(new Color(59, 89, 152));
        button.setForeground(Color.WHITE);
        button.setFont(new Font("Arial", Font.BOLD, 14));
        button.setPreferredSize(new Dimension(180, 40)); // Consider reducing size if needed
        button.setBorder(BorderFactory.createLineBorder(new Color(59, 89, 152)));
        return button;
    }

    // Sort-by in table
    private void enableSortingByDateTime(JTable table, DefaultTableModel model, int dateColumnIndex, int timeColumnIndex) {
        TableRowSorter<DefaultTableModel> sorter = new TableRowSorter<>(model);
        table.setRowSorter(sorter);

        // Define custom comparator for date and time columns
        sorter.setComparator(dateColumnIndex, (date1, date2) -> {
            try {
                SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy hh:mm a");
                Date d1 = sdf.parse((String) date1 + " 00:00 AM"); // Default to midnight if no time is specified
                Date d2 = sdf.parse((String) date2 + " 00:00 AM");
                return d1.compareTo(d2);
            } catch (Exception e) {
                return 0;
            }
        });

        sorter.setComparator(timeColumnIndex, (time1, time2) -> {
            try {
                SimpleDateFormat sdf = new SimpleDateFormat("hh:mm a");
                Date t1 = sdf.parse((String) time1);
                Date t2 = sdf.parse((String) time2);
                return t1.compareTo(t2);
            } catch (Exception e) {
                return 0;
            }
        });
    }

    // Move Past appointment to feedback table
    private void movePastAppointmentsToFeedback() {
        SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy hh:mm a");
        Date currentDate = new Date();

        for (int i = bookedAppointmentsModel.getRowCount() - 1; i >= 0; i--) {
            String dateStr = (String) bookedAppointmentsModel.getValueAt(i, 2);
            String timeStr = (String) bookedAppointmentsModel.getValueAt(i, 3);
            try {
                Date appointmentDate = sdf.parse(dateStr + " " + timeStr);
                if (appointmentDate.before(currentDate)) {
                    // Move to feedback table
                    String student = (String) bookedAppointmentsModel.getValueAt(i, 0);
                    String lecturer = (String) bookedAppointmentsModel.getValueAt(i, 1);
                    String status = "Past";  // Set the status to "Past"

                    feedbackModel.addRow(new Object[]{student, lecturer, dateStr, timeStr, status, "", ""});

                    // Remove from booked appointments table
                    bookedAppointmentsModel.removeRow(i);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        // Save updates to file
        saveAllAppointmentsToFile("appointments.txt");
        saveAllFeedbackToFile("feedback.txt");
    }

    // Remove past available slot
    private void removePastAvailableSlots() {
        SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy hh:mm a");
        Date currentDate = new Date();

        for (int i = availableSlotsModel.getRowCount() - 1; i >= 0; i--) {
            String dateStr = (String) availableSlotsModel.getValueAt(i, 1);
            String timeStr = (String) availableSlotsModel.getValueAt(i, 2);
            try {
                Date slotDate = sdf.parse(dateStr + " " + timeStr);
                if (slotDate.before(currentDate)) {
                    availableSlotsModel.removeRow(i);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        // Save updates to file
        saveAllSlotsToFile("available_slots.txt");
    }

    // Method to save slots to file
    private void saveSlotsToFile(String fileName, String lecturerName, String date, String time, String duration) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName, true))) {
            writer.write(lecturerName + "," + date + "," + time + "," + duration);
            writer.newLine();
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error saving slot to file.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // Method to save all slots to file
    private void saveAllSlotsToFile(String fileName) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName))) {
            for (int i = 0; i < availableSlotsModel.getRowCount(); i++) {
                String lecturerName = (String) availableSlotsModel.getValueAt(i, 0);
                String date = (String) availableSlotsModel.getValueAt(i, 1);
                String time = (String) availableSlotsModel.getValueAt(i, 2);
                String duration = (String) availableSlotsModel.getValueAt(i, 3);
                writer.write(lecturerName + "," + date + "," + time + "," + duration);
                writer.newLine();
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error saving slots to file.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // Method to save all appointments to file
    private void saveAllAppointmentsToFile(String fileName) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName))) {
            for (int i = 0; i < bookedAppointmentsModel.getRowCount(); i++) {
                String student = (String) bookedAppointmentsModel.getValueAt(i, 0);
                String lecturer = (String) bookedAppointmentsModel.getValueAt(i, 1);
                String date = (String) bookedAppointmentsModel.getValueAt(i, 2);
                String time = (String) bookedAppointmentsModel.getValueAt(i, 3);
                String duration = (String) bookedAppointmentsModel.getValueAt(i, 4);
                String status = (String) bookedAppointmentsModel.getValueAt(i, 5);
                writer.write(student + "," + lecturer + "," + date + "," + time + "," + duration + "," + status);
                writer.newLine();
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error saving appointments to file.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // Method to save all reschedule requests to file
    private void saveAllRescheduleRequestsToFile(String fileName) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName))) {
            for (int i = 0; i < rescheduleRequestsModel.getRowCount(); i++) {
                String student = (String) rescheduleRequestsModel.getValueAt(i, 0);
                String currentDate = (String) rescheduleRequestsModel.getValueAt(i, 1);
                String currentTime = (String) rescheduleRequestsModel.getValueAt(i, 2);
                String requestedDate = (String) rescheduleRequestsModel.getValueAt(i, 3);
                String requestedTime = (String) rescheduleRequestsModel.getValueAt(i, 4);
                writer.write(student + "," + currentDate + "," + currentTime + "," + requestedDate + "," + requestedTime);
                writer.newLine();
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error saving reschedule requests to file.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // Save the feedback to file
    private void saveAllFeedbackToFile(String fileName) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName))) {
            for (int i = 0; i < feedbackModel.getRowCount(); i++) {
                String studentName = (String) feedbackModel.getValueAt(i, 0);
                String lecturerName = (String) feedbackModel.getValueAt(i, 1);
                String date = (String) feedbackModel.getValueAt(i, 2);
                String time = (String) feedbackModel.getValueAt(i, 3);
                String status = (String) feedbackModel.getValueAt(i, 4);
                String studentFeedback = (String) feedbackModel.getValueAt(i, 5);
                String lecturerFeedback = (String) feedbackModel.getValueAt(i, 6);

                writer.write(studentName + "," + lecturerName + "," + date + "," + time + "," + status + "," + studentFeedback + "," + lecturerFeedback);
                writer.newLine();
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error saving feedback to file.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // Load available slots from file
    private void loadAvailableSlotsFromFile(String fileName) {
        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 4) {
                    availableSlotsModel.addRow(new Object[]{parts[0], parts[1], parts[2], parts[3], false});
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error loading available slots from file.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // Load booked appointments from file
    private void loadAppointmentsFromFile(String fileName) {
        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 6) {
                    bookedAppointmentsModel.addRow(new Object[]{parts[0], parts[1], parts[2], parts[3], parts[4], parts[5], false});
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error loading appointments from file.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // Load reschedule requests from file
    private void loadRescheduleRequestsFromFile(String fileName) {
        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 5) {
                    rescheduleRequestsModel.addRow(new Object[]{parts[0], parts[1], parts[2], parts[3], parts[4], false});
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error loading reschedule requests from file.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // Load feedback from file
    private void loadFeedbackFromFile(String fileName) {
        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",", 7);
                if (parts.length == 7) {
                    feedbackModel.addRow(new Object[]{parts[0], parts[1], parts[2], parts[3], parts[4], parts[5], parts[6]});
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error loading feedback from file.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public static void main(String[] args) {
        new LecturerPage("Lecturer");
    }
}
