package Assignment;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;

public class StudentPage extends JFrame {

    private DefaultTableModel model;
    private JTable studenttable;
    private DefaultTableModel rescheduleModel;
    private JTable rescheduleTable;
    private DefaultTableModel feedbackModel;
    private JTable feedbackTable;
    private DefaultTableModel availableSlotModel;
    private JTable availableSlotTable;
    private String studentName;

    public StudentPage(String studentName) {
        this.studentName = studentName;
        setTitle("Student Management");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1500, 800);
        setResizable(true);
        getContentPane().setBackground(new Color(245, 245, 245));
        setLayout(new GridBagLayout());
        ((JPanel) getContentPane()).setBorder(new EmptyBorder(20, 20, 20, 20));

        GridBagConstraints layout = new GridBagConstraints();
        layout.insets = new Insets(10, 10, 10, 10);
        layout.fill = GridBagConstraints.BOTH;
        layout.weightx = 1.0;
        layout.weighty = 1.0;

        // Title Label
        JLabel titleLabel = new JLabel("Student Management Page", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 28));
        titleLabel.setForeground(new Color(60, 60, 120));
        layout.gridx = 0;
        layout.gridy = 0;
        layout.gridwidth = 2;
        layout.weighty = 0.1;
        add(titleLabel, layout);

        // Appointments Table
        String[] columnNames = {"Student", "Lecturer", "Date (MM/DD/YYYY)", "Time", "Duration (mins)", "Status"};
        Object[][] data = readAppointmentData("appointments.txt");
        model = new DefaultTableModel(data, columnNames) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        studenttable = new JTable(model);
        styleTable(studenttable);
        enableSortingByDateTime(studenttable, model, 2, 3);
        JScrollPane scrollPane = new JScrollPane(studenttable);
        scrollPane.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(new Color(60, 60, 120)), "Appointments", 0, 0, new Font("Arial", Font.BOLD, 14), new Color(60, 60, 120)));
        layout.gridy = 1;
        layout.gridwidth = 1;
        layout.weighty = 1.0;
        add(scrollPane, layout);

        // Available Slots Table
        String[] availableSlotColumnNames = {"Lecturer Name", "Date (MM/DD/YYYY)", "Time", "Duration (mins)"};
        Object[][] availableSlotData = readAvailableSlotData("available_slots.txt");
        availableSlotModel = new DefaultTableModel(availableSlotData, availableSlotColumnNames);
        availableSlotTable = new JTable(availableSlotModel);
        styleTable(availableSlotTable);
        enableSortingByDateTime(availableSlotTable, availableSlotModel, 1, 2);
        JScrollPane availableSlotScrollPane = new JScrollPane(availableSlotTable);
        availableSlotScrollPane.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(new Color(60, 60, 120)), "Available Slots", 0, 0, new Font("Arial", Font.BOLD, 14), new Color(60, 60, 120)));
        layout.gridy = 2;
        add(availableSlotScrollPane, layout);

        // Reschedule Requests Table
        String[] rescheduleColumnNames = {"Student", "Lecturer", "Current Date & Time", "Requested Date", "Requested Time"};
        Object[][] rescheduleData = readRescheduleData("reschedule_requests.txt");
        rescheduleModel = new DefaultTableModel(rescheduleData, rescheduleColumnNames);
        rescheduleTable = new JTable(rescheduleModel);
        styleTable(rescheduleTable);
        JScrollPane rescheduleScrollPane = new JScrollPane(rescheduleTable);
        rescheduleScrollPane.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(new Color(60, 60, 120)), "Reschedule Requests", 0, 0, new Font("Arial", Font.BOLD, 14), new Color(60, 60, 120)));
        layout.gridy = 3;
        add(rescheduleScrollPane, layout);

        // Feedback Table
        String[] feedbackColumnNames = {"Student Name", "Lecturer Name", "Date (MM/DD/YYYY)", "Time", "Status", "Student Feedback", "Lecturer Feedback"};
        Object[][] feedbackData = readFeedbackData("feedback.txt");
        feedbackModel = new DefaultTableModel(feedbackData, feedbackColumnNames);
        feedbackTable = new JTable(feedbackModel);
        styleTable(feedbackTable);
        enableSortingByDateTime(feedbackTable, feedbackModel, 2, 3);
        JScrollPane feedbackScrollPane = new JScrollPane(feedbackTable);
        feedbackScrollPane.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(new Color(60, 60, 120)), "Consultation Feedback", 0, 0, new Font("Arial", Font.BOLD, 14), new Color(60, 60, 120)));
        layout.gridy = 4;
        add(feedbackScrollPane, layout);

        // Bottom Panel with Buttons
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        bottomPanel.setBackground(new Color(245, 245, 245));
        JButton makeAppointmentButton = createStyledButton("Make Appointment");
        JButton requestRescheduleButton = createStyledButton("Request Reschedule");
        JButton provideFeedbackButton = createStyledButton("Provide Feedback");
        JButton cancelAppointmentButton = createStyledButton("Cancel Appointment"); // New Button
        JButton logoutButton = createStyledButton("Log Out");

        bottomPanel.add(makeAppointmentButton);
        bottomPanel.add(requestRescheduleButton);
        bottomPanel.add(provideFeedbackButton);
        bottomPanel.add(cancelAppointmentButton); // Add new button to panel
        bottomPanel.add(logoutButton);

        layout.gridy = 5;
        layout.weighty = 0.1;
        layout.gridwidth = 2;
        layout.fill = GridBagConstraints.HORIZONTAL;
        add(bottomPanel, layout);


        // Button Actions for make appointment button
        makeAppointmentButton.addActionListener(e -> {
            int selectedRow = availableSlotTable.getSelectedRow();
            if (selectedRow == -1) {
                JOptionPane.showMessageDialog(this, "Please select an available slot to book an appointment.", "No Slot Selected", JOptionPane.WARNING_MESSAGE);
                return;
            }

            String lecturerName = (String) availableSlotModel.getValueAt(selectedRow, 0);
            String date = (String) availableSlotModel.getValueAt(selectedRow, 1);
            String time = (String) availableSlotModel.getValueAt(selectedRow, 2);
            String duration = (String) availableSlotModel.getValueAt(selectedRow, 3);

            int result = JOptionPane.showConfirmDialog(this, "Book appointment with " + lecturerName + " on " + date + " at " + time + " (Duration: " + duration + " mins)?", "Confirm Appointment", JOptionPane.YES_NO_OPTION);
            if (result == JOptionPane.YES_OPTION) {
                // Automatically use the student's name from the logged-in session
                model.addRow(new Object[]{studentName, lecturerName, date, time, duration, "Booked"});
                saveAppointmentData("appointments.txt");
                JOptionPane.showMessageDialog(this, "Appointment booked successfully for " + lecturerName + " on " + date + " at " + time + " (Duration: " + duration + " mins).", "Appointment Booked", JOptionPane.INFORMATION_MESSAGE);

                // Remove booked slot from available slots table
                availableSlotModel.removeRow(selectedRow);
                saveAllAvailableSlotsToFile("available_slots.txt");
            }
        });

        // Button Actions for request reschedule button
        requestRescheduleButton.addActionListener(e -> {
            int selectedRow = studenttable.getSelectedRow();
            if (selectedRow == -1) {
                JOptionPane.showMessageDialog(this, "Please select an appointment to request reschedule.", "No Appointment Selected", JOptionPane.WARNING_MESSAGE);
                return;
            }

            String lecturerName = (String) model.getValueAt(selectedRow, 1);
            String currentDate = (String) model.getValueAt(selectedRow, 2);
            String currentTime = (String) model.getValueAt(selectedRow, 3);

            JPanel panel = new JPanel(new GridBagLayout());
            GridBagConstraints layout2 = new GridBagConstraints();
            layout2.insets = new Insets(5, 5, 5, 5);
            layout2.fill = GridBagConstraints.HORIZONTAL;

            JLabel currentDetailsLabel = new JLabel("Current Appointment: " + currentDate + " at " + currentTime);
            layout2.gridx = 0;
            layout2.gridy = 0;
            layout2.gridwidth = 2;
            panel.add(currentDetailsLabel, layout2);

            JLabel availableSlotsLabel = new JLabel("Select a new slot from Available Slots:");
            layout2.gridy = 1;
            panel.add(availableSlotsLabel, layout2);

            JTable slotTable = new JTable(availableSlotModel);
            slotTable.setFillsViewportHeight(true);
            JScrollPane slotScrollPane = new JScrollPane(slotTable);
            layout2.gridy = 2;
            layout2.gridwidth = 2;
            layout2.fill = GridBagConstraints.BOTH;
            panel.add(slotScrollPane, layout2);

            int result = JOptionPane.showConfirmDialog(this, panel, "Request Reschedule", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

            if (result == JOptionPane.OK_OPTION) {
                int selectedSlotRow = slotTable.getSelectedRow();
                if (selectedSlotRow == -1) {
                    JOptionPane.showMessageDialog(this, "Please select a new slot for rescheduling.", "No Slot Selected", JOptionPane.WARNING_MESSAGE);
                    return;
                }

                String newDate = (String) availableSlotModel.getValueAt(selectedSlotRow, 1);
                String newTime = (String) availableSlotModel.getValueAt(selectedSlotRow, 2);

                // Confirm the reschedule request
                int confirmResult = JOptionPane.showConfirmDialog(this,
                        "Reschedule appointment with " + lecturerName + " to " + newDate + " at " + newTime + "?",
                        "Confirm Reschedule", JOptionPane.YES_NO_OPTION);

                if (confirmResult == JOptionPane.YES_OPTION) {
                    // Add the reschedule request to the reschedule model
                    rescheduleModel.addRow(new Object[]{studentName, lecturerName, currentDate + " " + currentTime, newDate, newTime});
                    saveRescheduleData("reschedule_requests.txt");

                    // Remove the original appointment and save the changes
                    model.removeRow(selectedRow);
                    saveAppointmentData("appointments.txt");

                    // Remove the selected slot from available slots and save the changes
                    availableSlotModel.removeRow(selectedSlotRow);
                    saveAllAvailableSlotsToFile("available_slots.txt");

                    JOptionPane.showMessageDialog(this, "Reschedule request submitted successfully.", "Request Submitted", JOptionPane.INFORMATION_MESSAGE);
                }
            }

        });

        // Button Actions for provide feedback button
        provideFeedbackButton.addActionListener(e -> {
            int selectedRow = feedbackTable.getSelectedRow();
            if (selectedRow == -1) {
                JOptionPane.showMessageDialog(this, "Please select an appointment from the Consultation Feedback table to provide feedback.", "No Appointment Selected", JOptionPane.WARNING_MESSAGE);
                return;
            }

            // Retrieve the details of the selected appointment
            String lecturerName = (String) feedbackModel.getValueAt(selectedRow, 1);
            String date = (String) feedbackModel.getValueAt(selectedRow, 2);
            String time = (String) feedbackModel.getValueAt(selectedRow, 3);
            String status = (String) feedbackModel.getValueAt(selectedRow, 4);


            // Prompt the student to provide feedback
            String studentFeedback = JOptionPane.showInputDialog(this, "Provide feedback for " + lecturerName + " on " + date + " at " + time + ":", "Provide Feedback", JOptionPane.PLAIN_MESSAGE);

            // Check if feedback was provided
            if (studentFeedback != null && !studentFeedback.trim().isEmpty()) {
                // Update the feedback table model with the provided feedback
                feedbackModel.setValueAt(studentFeedback, selectedRow, 5);

                // Save the feedback to the feedback file
                saveFeedbackData("feedback.txt");  // Added to save feedback immediately after submission

                JOptionPane.showMessageDialog(this, "Feedback submitted successfully.", "Feedback Submitted", JOptionPane.INFORMATION_MESSAGE);
            }
        });

        // Button Actions for cancel appointment button 
        cancelAppointmentButton.addActionListener(e -> {
            int selectedRow = studenttable.getSelectedRow();
            if (selectedRow == -1) {
                JOptionPane.showMessageDialog(this, "Please select an appointment to cancel.", "No Appointment Selected", JOptionPane.WARNING_MESSAGE);
                return;
            }

            String lecturerName = (String) model.getValueAt(selectedRow, 1);
            String date = (String) model.getValueAt(selectedRow, 2);
            String time = (String) model.getValueAt(selectedRow, 3);
            String duration = (String) model.getValueAt(selectedRow, 4);
            String status = (String) model.getValueAt(selectedRow, 5);

            // Confirm cancellation
            int confirm = JOptionPane.showConfirmDialog(this,
                    "Are you sure you want to cancel the appointment with " + lecturerName + " on " + date + " at " + time + "?",
                    "Confirm Cancellation", JOptionPane.YES_NO_OPTION);

            if (confirm == JOptionPane.YES_OPTION) {
                // Remove the appointment from the appointments table
                model.removeRow(selectedRow);
                saveAppointmentData("appointments.txt");

                // Add the canceled appointment to the feedback table with status "Canceled"
                feedbackModel.addRow(new Object[]{studentName, lecturerName, date, time, "Canceled", "", ""});
                saveFeedbackData("feedback.txt");

                JOptionPane.showMessageDialog(this, "Appointment canceled successfully.", "Appointment Canceled", JOptionPane.INFORMATION_MESSAGE);
            }
        });

        logoutButton.addActionListener(e -> {
            dispose();
            new MainPage();
        });

        setAutoMoveToFeedback();
        setVisible(true);
    }

    private JButton createStyledButton(String text) {
        JButton button = new JButton(text);
        button.setFocusPainted(false);
        button.setBackground(new Color(60, 60, 120));
        button.setForeground(Color.WHITE);
        button.setFont(new Font("Arial", Font.BOLD, 14));
        button.setPreferredSize(new Dimension(180, 40));
        button.setBorder(BorderFactory.createLineBorder(new Color(60, 60, 120)));
        return button;
    }

    private void styleTable(JTable table) {
        table.setRowHeight(30);
        table.setFont(new Font("Arial", Font.PLAIN, 14));
        table.getTableHeader().setFont(new Font("Arial", Font.BOLD, 14));
        table.getTableHeader().setBackground(new Color(60, 60, 120));
        table.getTableHeader().setForeground(Color.WHITE);
        table.setGridColor(new Color(200, 200, 200));
    }

    private void enableSortingByDateTime(JTable table, DefaultTableModel model, int dateColumnIndex, int timeColumnIndex) {
        TableRowSorter<DefaultTableModel> sorter = new TableRowSorter<>(model);
        table.setRowSorter(sorter);

        // Define custom comparator for date and time columns
        sorter.setComparator(dateColumnIndex, (date1, date2) -> {
            try {
                SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy hh:mm a");
                Date d1 = sdf.parse((String) date1 + " 00:00 AM"); // Default to midnight if no time is specified
                Date d2 = sdf.parse((String) date2 + " 00:00 AM");
                return d1.compareTo(d2);
            } catch (Exception e) {
                return 0;
            }
        });

        sorter.setComparator(timeColumnIndex, (time1, time2) -> {
            try {
                SimpleDateFormat sdf = new SimpleDateFormat("hh:mm a");
                Date t1 = sdf.parse((String) time1);
                Date t2 = sdf.parse((String) time2);
                return t1.compareTo(t2);
            } catch (Exception e) {
                return 0;
            }
        });
    }

    private void setAutoMoveToFeedback() {
        Timer timer = new Timer(true);
        timer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                SwingUtilities.invokeLater(() -> movePassedAppointmentsToFeedback());
            }
        }, 0, 60 * 1000);  // Check every minute
    }

     // Move Past Appointments to Feedback Table
    private void movePassedAppointmentsToFeedback() {
        SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy hh:mm a");
        Date currentDate = new Date();

        // Move Past appointments from the appointments table
        for (int i = model.getRowCount() - 1; i >= 0; i--) {
            String dateStr = (String) model.getValueAt(i, 2);
            String timeStr = (String) model.getValueAt(i, 3);
            try {
                Date appointmentDate = sdf.parse(dateStr + " " + timeStr);
                if (appointmentDate.before(currentDate)) {
                    // Move to feedback table
                    String student = (String) model.getValueAt(i, 0);
                    String lecturer = (String) model.getValueAt(i, 1);
                    String status = "Past";  // Set the status to "Past"

                    feedbackModel.addRow(new Object[]{student, lecturer, dateStr, timeStr, status, "", ""});

                    // Remove from appointment table
                    model.removeRow(i);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        // Move Past available slots from the available slots table
        for (int i = availableSlotModel.getRowCount() - 1; i >= 0; i--) {
            String dateStr = (String) availableSlotModel.getValueAt(i, 1);
            String timeStr = (String) availableSlotModel.getValueAt(i, 2);
            try {
                Date slotDate = sdf.parse(dateStr + " " + timeStr);
                if (slotDate.before(currentDate)) {
                    // Remove from available slots table
                    availableSlotModel.removeRow(i);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        // Save updates to files
        saveAppointmentData("appointments.txt");
        saveFeedbackData("feedback.txt");
        saveAllAvailableSlotsToFile("available_slots.txt");
    }
    

    private Object[][] readAppointmentData(String fileName) {
        List<Object[]> dataList = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 6) {
                    // Adding false for the Select column (checkbox)
                    Object[] row = new Object[]{parts[0], parts[1], parts[2], parts[3], parts[4], parts[5]};
                    dataList.add(row);
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error reading appointment data from file.", "Error", JOptionPane.ERROR_MESSAGE);
        }
        return dataList.toArray(new Object[0][]);
    }


    private Object[][] readAvailableSlotData(String fileName) {
        List<Object[]> dataList = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 4) {
                    dataList.add(parts);
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error reading available slots data from file.", "Error", JOptionPane.ERROR_MESSAGE);
        }
        return dataList.toArray(new Object[0][]);
    }

    private Object[][] readRescheduleData(String fileName) {
        List<Object[]> dataList = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 5) {
                    dataList.add(parts);
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error reading reschedule data from file.", "Error", JOptionPane.ERROR_MESSAGE);
        }
        return dataList.toArray(new Object[0][]);
    }

    private Object[][] readFeedbackData(String fileName) {
        List<Object[]> dataList = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",", 7); // Now expecting 7 columns in the feedback file
                if (parts.length == 7) {
                    dataList.add(parts);
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error reading feedback data from file.", "Error", JOptionPane.ERROR_MESSAGE);
        }
        return dataList.toArray(new Object[0][]);
    }


    private void saveAppointmentData(String fileName) {
        try (FileWriter writer = new FileWriter(fileName)) {
            for (int i = 0; i < model.getRowCount(); i++) {
                String studentName = (String) model.getValueAt(i, 0);
                String lecturerName = (String) model.getValueAt(i, 1);
                String date = (String) model.getValueAt(i, 2);
                String time = (String) model.getValueAt(i, 3);
                String duration = (String) model.getValueAt(i, 4);
                String status = (String) model.getValueAt(i, 5);
                writer.write(studentName + "," + lecturerName + "," + date + "," + time + "," + duration + "," + status + "\n");
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error saving appointment data to file.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void saveAllAvailableSlotsToFile(String fileName) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName))) {
            for (int i = 0; i < availableSlotModel.getRowCount(); i++) {
                String lecturerName = (String) availableSlotModel.getValueAt(i, 0);
                String date = (String) availableSlotModel.getValueAt(i, 1);
                String time = (String) availableSlotModel.getValueAt(i, 2);
                String duration = (String) availableSlotModel.getValueAt(i, 3);
                writer.write(lecturerName + "," + date + "," + time + "," + duration);
                writer.newLine();
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error saving available slots to file.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void saveRescheduleData(String fileName) {
        try (FileWriter writer = new FileWriter(fileName)) {
            for (int i = 0; i < rescheduleModel.getRowCount(); i++) {
                String lecturerName = (String) rescheduleModel.getValueAt(i, 0);
                String currentDate = (String) rescheduleModel.getValueAt(i, 1);
                String currentTime = (String) rescheduleModel.getValueAt(i, 2);
                String requestedDate = (String) rescheduleModel.getValueAt(i, 3);
                String requestedTime = (String) rescheduleModel.getValueAt(i, 4);
                writer.write(lecturerName + "," + currentDate + "," + currentTime + "," + requestedDate + "," + requestedTime + "\n");
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error saving reschedule data to file.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void saveFeedbackData(String fileName) {
        try (FileWriter writer = new FileWriter(fileName)) {
            for (int i = 0; i < feedbackModel.getRowCount(); i++) {
                String studentName = (String) feedbackModel.getValueAt(i, 0);
                String lecturerName = (String) feedbackModel.getValueAt(i, 1);
                String date = (String) feedbackModel.getValueAt(i, 2);
                String time = (String) feedbackModel.getValueAt(i, 3);
                String status = (String) feedbackModel.getValueAt(i, 4);
                String studentFeedback = (String) feedbackModel.getValueAt(i, 5);
                String lecturerFeedback = (String) feedbackModel.getValueAt(i, 6);
                writer.write(studentName + "," + lecturerName + "," + date + "," + time + "," + status + "," + studentFeedback + "," + lecturerFeedback + "\n");
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error saving feedback data to file.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    

    public static void main(String[] args) {
        new StudentPage("Student");
    }
}
